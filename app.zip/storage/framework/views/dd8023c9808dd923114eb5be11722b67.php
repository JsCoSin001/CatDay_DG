<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="color-scheme" content="light">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Công đoạn cắt/lấy dây'); ?></title>

    
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
        crossorigin="anonymous"
    >

    <link rel="stylesheet" href="<?php echo e(asset('css/qr-scanner/qr-camera-modal.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cat-day/cat-day-ui.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    
    <script src="<?php echo e(asset('js/qr-scanner/lib/html5-qrcode.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/qr-scanner/lib/jsQR.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/qr-scanner/qr-image-decoder.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/qr-scanner/qr-camera-scanner.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/qr-scanner/qr-camera-modal.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/cat-day/b3-api.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/cat-day/b3-state.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/cat-day/cat-day-ui.js')); ?>" defer></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\02. PROJECTS\01. SỐ HOÁ\03. Version 03\Tools\ĐG\Kho\CatDay_App\resources\views/layouts/cat-day.blade.php ENDPATH**/ ?>